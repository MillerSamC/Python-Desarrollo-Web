def suma(x,y):
  return x + y

x = 10
y = 20
z = suma(x,y)
print(z)


